import {NgModule} from '@angular/core';
import {MyAppComponent} from './app.component';
import {BrowserModule} from '@angular/platform-browser';

@NgModule({
    imports : [BrowserModule],
    bootstrap : [MyAppComponent],
    declarations : [MyAppComponent]
})
export class MyAppModule{

}