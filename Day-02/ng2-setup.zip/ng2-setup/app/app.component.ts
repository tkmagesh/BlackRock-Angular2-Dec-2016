import {Component}  from '@angular/core'


@Component({
    selector : 'myapp',
    template : '<div>Welcome to Angular 2.0</div>'
})
export class MyAppComponent{
    
}

